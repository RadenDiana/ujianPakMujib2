/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ujianpakmujib2;

import static java.lang.System.out;
import javax.swing.JOptionPane;

/**
 *
 * @author PC 26 - LAB R1
 */
public class Ujianpakmujib2 {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
//         while (true) {
//            String menu = JOptionPane.showInputDialog(
//                "Menu:\n1. Piramida Kebalik\n2. Segitiga Angka\n3. Keluar\n\nPilihan Anda:"
//            );
//            if (menu == null || menu.equals("3")) break;
//
//            int pilihan = Integer.parseInt(menu);
//            String input = JOptionPane.showInputDialog("Masukkan jumlah baris:");
//            int baris = Integer.parseInt(input);
//            StringBuilder out = new StringBuilder();
//
//            if (pilihan == 1) {
//                for (int i = baris; i >= 1; i--) {
//                    out.append("  ".repeat(baris - i));
//                    out.append("* ".repeat(2 * i - 1)).append("\n");
//                }
//                JOptionPane.showMessageDialog(null, out.toString(), "Piramida Kebalik", 1);
//            } else if (pilihan == 2) {
//                for (int i = 1; i <= baris; i++) {
//                    for (int j = 1; j < i; j++) out.append(j);
//                    out.append("\n");
//                }
//                JOptionPane.showMessageDialog(null, out.toString(), "Segitiga Angka", 1);
//            } else {
//                JOptionPane.showMessageDialog(null, "Pilihan tidak valid.");
//            }
//        }




//int jumlahBarisPiramid =  Integer.parseInt(JOptionPane.showInputDialog(null,
//"Masukan jumlah piramid : ",
//"Input",
//JOptionPane.INFORMATION_MESSAGE));
//
//   for (int i = 0; i <= jumlahBarisPiramid; i++) {
//   for (int j = 0; j < i; j++) {
//   System.out.print("* ");
//   } 
//   System.out.println("");
//   }
//    for (int i = jumlahBarisPiramid; i >= 1; i--) {
//     for (int j = 0; j < i; j++) {
//     System.out.print("* "); 
//    }
//     System.out.println("");
//    }


int baris =  Integer.parseInt(JOptionPane.showInputDialog(null,
"Masukan jumlah piramid : ",
"Input",
JOptionPane.INFORMATION_MESSAGE));

for (int i = baris; i >= 1; i--) {
                    out.append("  ".repeat(baris - i));
                    out.append("* ".repeat(2 * i - 1)).append("\n");
                }
for (int i = baris; i <= 1; i++) {
out.append("  ".repeat(baris - i));
out.append("* ".repeat(2 * i - 1)).append("\n");
}
                JOptionPane.showMessageDialog(null, out.toString(), "Piramida Kebalik", 1);
   


    }    
}
